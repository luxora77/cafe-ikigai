
import React, { useState, useEffect } from 'react';

interface HeaderProps {
  onReserve: () => void;
}

const Header: React.FC<HeaderProps> = ({ onReserve }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToId = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 100;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
      setIsMobileMenuOpen(false);
    }
  };

  const navLinks = [
    { label: 'Menu', id: 'menu' },
    { label: 'Reviews', id: 'reviews' },
    { label: 'Contact', id: 'contact' },
  ];

  return (
    <header 
      className={`fixed top-0 z-50 w-full transition-all duration-700 ${
        isScrolled 
          ? 'bg-charcoal/40 backdrop-blur-2xl py-5 border-b border-white/5' 
          : 'bg-transparent py-10 border-b border-transparent'
      } px-6 lg:px-20`}
    >
      <div className="max-w-[1440px] mx-auto flex items-center justify-between">
        <div className="flex items-center gap-4 group cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="size-10 bg-primary/10 border border-primary/20 flex items-center justify-center text-primary group-hover:rotate-[360deg] transition-all duration-1000">
             <svg fill="none" className="size-6" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
              <path clipRule="evenodd" d="M47.2426 24L24 47.2426L0.757355 24L24 0.757355L47.2426 24ZM12.2426 21H35.7574L24 9.24264L12.2426 21Z" fill="currentColor" fillRule="evenodd"></path>
            </svg>
          </div>
          <h1 className="text-3xl font-display font-black tracking-tighter uppercase italic">Ikigai</h1>
        </div>

        <nav className="hidden md:flex items-center gap-16">
          {navLinks.map((link) => (
            <button 
              key={link.label} 
              className="nav-link" 
              onClick={() => scrollToId(link.id)}
            >
              {link.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-8">
          <button 
            onClick={onReserve}
            className="hidden sm:block relative overflow-hidden px-10 py-4 bg-primary text-white text-[10px] uppercase tracking-[0.3em] font-black transition-all hover:bg-accent hover:-translate-y-0.5 shadow-xl"
          >
            Reserve Table
          </button>
          
          <button 
            className="md:hidden text-white p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <span className="material-symbols-outlined text-4xl">
              {isMobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </div>

      <div 
        className={`md:hidden absolute top-full left-0 w-full bg-charcoal/95 backdrop-blur-3xl border-b border-white/5 transition-all duration-500 ease-in-out ${
          isMobileMenuOpen ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'
        } overflow-hidden`}
      >
        <div className="p-12 flex flex-col gap-10">
          {navLinks.map((link) => (
            <button 
              key={link.label} 
              className="text-left text-4xl font-display italic text-cream/60 hover:text-white transition-colors" 
              onClick={() => scrollToId(link.id)}
            >
              {link.label}
            </button>
          ))}
          <button 
            onClick={() => {
              onReserve();
              setIsMobileMenuOpen(false);
            }}
            className="bg-primary text-white py-6 uppercase tracking-[0.4em] font-black text-xs"
          >
            Instant Booking
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
