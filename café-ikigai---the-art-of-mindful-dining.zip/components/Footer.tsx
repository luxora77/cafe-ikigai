
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-charcoal text-white py-32 px-6 lg:px-20 border-t border-white/5" id="contact">
      <div className="max-w-[1440px] mx-auto grid lg:grid-cols-4 gap-20">
        <div className="lg:col-span-1">
          <div className="flex items-center gap-4 mb-10 group">
            <div className="size-8 text-primary transition-transform group-hover:rotate-12">
              <svg fill="none" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
                <path clipRule="evenodd" d="M47.2426 24L24 47.2426L0.757355 24L24 0.757355L47.2426 24ZM12.2426 21H35.7574L24 9.24264L12.2426 21Z" fill="currentColor" fillRule="evenodd"></path>
              </svg>
            </div>
            <h2 className="text-3xl font-display font-black tracking-tighter italic uppercase">Ikigai</h2>
          </div>
          <p className="text-white/40 font-light leading-relaxed text-sm mb-10">
            Plot 45, Silicon Valley, Kondapur, Hyderabad.<br />
            Where Japanese precision meets Indian heart.
          </p>
          <div className="flex gap-6 mb-10">
            <a href="#" className="size-12 rounded-full border border-white/5 flex items-center justify-center hover:border-primary hover:text-primary transition-all text-[10px] font-black tracking-widest bg-white/[0.02]">INSTA</a>
            <a href="#" className="size-12 rounded-full border border-white/5 flex items-center justify-center hover:border-primary hover:text-primary transition-all text-[10px] font-black tracking-widest bg-white/[0.02]">FACE</a>
          </div>
          
          {/* Embedded Map */}
          <div className="w-full h-48 border border-white/5 overflow-hidden">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.2795325983777!2d78.36272457597116!3d17.45579520000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9300593cb35f%3A0x36921c79f419b015!2sCaf%C3%A9%20Ikigai%20-%20Whitefields%2C%20Kondapur!5e0!3m2!1sen!2sin!4v1716300000000!5m2!1sen!2sin" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen={true} 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              className="grayscale invert opacity-50 hover:opacity-100 transition-opacity"
            />
          </div>
        </div>
        
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.4em] font-black mb-10 text-primary">Location</h3>
          <p className="text-white/60 leading-relaxed font-light text-lg">
            Cafe Ikigai - Whitefields,<br />
            Plot No 45, Whitefields Rd,<br />
            Silicon Valley, Kondapur,<br />
            Hyderabad, Telangana 500084
          </p>
        </div>
        
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.4em] font-black mb-10 text-primary">Ritual Hours</h3>
          <p className="text-white/60 leading-relaxed font-light text-lg">
            Mon — Thu: 08:00 - 23:00<br />
            Fri — Sun: 08:00 - 00:00
          </p>
        </div>
        
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.4em] font-black mb-10 text-primary">Inquiries</h3>
          <div className="flex flex-col gap-6">
            <a className="text-white/60 hover:text-primary transition-colors font-light text-xl" href="tel:+919876543210">+91 98765 43210</a>
            <a className="text-white/60 hover:text-primary transition-colors font-light text-xl" href="mailto:hello@cafeikigai.com">hello@cafeikigai.com</a>
          </div>
        </div>
      </div>
      
      <div className="max-w-[1440px] mx-auto mt-32 pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
        <p className="text-[10px] text-white/20 uppercase tracking-[0.4em] font-black italic">© 2024 Café Ikigai. Crafted with Purpose.</p>
        <div className="flex gap-12 text-[10px] text-white/20 uppercase tracking-[0.4em] font-black italic">
          <a className="hover:text-white transition-colors cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>Privacy Policy</a>
          <a className="hover:text-white transition-colors cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>Terms of Sanctuary</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
