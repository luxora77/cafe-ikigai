
import React from 'react';

const VisitUs: React.FC = () => {
  return (
    <section className="py-40 bg-charcoal overflow-hidden" id="contact">
      <div className="container mx-auto px-6 lg:px-20">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="reveal">
            <span className="text-primary uppercase tracking-[0.4em] text-[10px] font-black mb-4 block">Visit the Sanctuary</span>
            <h2 className="text-5xl md:text-7xl mb-12 font-display">Find Your <br /> Place at Ikigai</h2>
            
            <div className="space-y-12">
              <div className="flex gap-8 group">
                <div className="size-16 border border-white/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all duration-500">
                  <span className="material-symbols-outlined">location_on</span>
                </div>
                <div>
                  <h4 className="text-xl font-display mb-2 text-brass">The Location</h4>
                  <p className="text-white/40 leading-relaxed font-light">
                    Plot No 45, Whitefields Rd, Silicon Valley,<br />
                    Kondapur, Hyderabad, Telangana 500084
                  </p>
                </div>
              </div>

              <div className="flex gap-8 group">
                <div className="size-16 border border-white/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all duration-500">
                  <span className="material-symbols-outlined">schedule</span>
                </div>
                <div>
                  <h4 className="text-xl font-display mb-2 text-brass">Ritual Hours</h4>
                  <div className="text-white/40 leading-relaxed font-light grid grid-cols-2 gap-x-8">
                    <span>Mon — Thu:</span> <span>08:00 - 23:00</span>
                    <span>Fri — Sun:</span> <span>08:00 - 00:00</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-16">
              <a 
                href="https://www.google.com/maps/dir//Caf%C3%A9+Ikigai+-+Whitefields,+Kondapur" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-4 px-10 py-5 bg-white text-charcoal font-black uppercase tracking-[0.2em] text-[10px] hover:bg-primary hover:text-white transition-all"
              >
                Get Directions <span className="material-symbols-outlined text-lg">near_me</span>
              </a>
            </div>
          </div>

          <div className="relative h-[600px] border border-white/5 shadow-2xl reveal">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.2795325983777!2d78.36272457597116!3d17.45579520000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9300593cb35f%3A0x36921c79f419b015!2sCaf%C3%A9%20Ikigai%20-%20Whitefields%2C%20Kondapur!5e0!3m2!1sen!2sin!4v1716300000000!5m2!1sen!2sin" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen={true} 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              className="grayscale invert opacity-60 hover:opacity-100 transition-opacity duration-1000"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default VisitUs;
