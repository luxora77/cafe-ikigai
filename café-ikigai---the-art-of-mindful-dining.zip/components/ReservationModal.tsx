
import React from 'react';

interface ReservationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ReservationModal: React.FC<ReservationModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your interest! In a real application, this would send your reservation request to our system.');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-charcoal/80 backdrop-blur-md"
        onClick={onClose}
      />
      
      <div className="relative bg-[#1e1e1e] border border-white/10 w-full max-w-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-300">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-white/50 hover:text-white"
        >
          <span className="material-symbols-outlined">close</span>
        </button>
        
        <div className="grid md:grid-cols-5 h-full">
          <div className="hidden md:block md:col-span-2 relative">
            <img 
              src="https://picsum.photos/seed/ikigai-res/400/600" 
              alt="Reservation" 
              className="absolute inset-0 w-full h-full object-cover grayscale opacity-50"
            />
            <div className="absolute inset-0 bg-primary/20" />
            <div className="absolute bottom-10 left-6 text-white">
               <p className="font-display italic text-2xl">Create a memory.</p>
            </div>
          </div>
          
          <div className="md:col-span-3 p-10">
            <h2 className="text-4xl font-display mb-2">Reserve a Table</h2>
            <p className="text-white/50 text-sm mb-8">Secure your sanctuary at Café Ikigai.</p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <input 
                  type="text" 
                  placeholder="Full Name" 
                  required
                  className="w-full bg-white/5 border border-white/10 p-4 focus:outline-none focus:border-primary transition-colors text-sm"
                />
                <div className="grid grid-cols-2 gap-4">
                  <input 
                    type="date" 
                    required
                    className="w-full bg-white/5 border border-white/10 p-4 focus:outline-none focus:border-primary transition-colors text-sm"
                  />
                  <input 
                    type="time" 
                    required
                    className="w-full bg-white/5 border border-white/10 p-4 focus:outline-none focus:border-primary transition-colors text-sm"
                  />
                </div>
                <select className="w-full bg-white/5 border border-white/10 p-4 focus:outline-none focus:border-primary transition-colors text-sm">
                  <option value="1">1 Person</option>
                  <option value="2">2 People</option>
                  <option value="3">3 People</option>
                  <option value="4">4 People</option>
                  <option value="5+">5+ People</option>
                </select>
              </div>
              
              <button 
                type="submit"
                className="w-full bg-primary hover:bg-accent py-5 uppercase tracking-widest font-bold text-xs transition-all shadow-xl"
              >
                Confirm Booking
              </button>
              
              <p className="text-[10px] text-center text-white/30 uppercase tracking-widest">
                Reservations are subject to availability.
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReservationModal;
