
import React, { useState } from 'react';
import ReviewModal from './ReviewModal';
import { GoogleGenAI, Type } from "@google/genai";

interface Review {
  id: number;
  name: string;
  rating: number;
  comment: string;
  date: string;
}

const initialReviews: Review[] = [
  {
    id: 1,
    name: "Vikram Malhotra",
    rating: 5,
    comment: "The Hario V60 here is the best I've had in Hyderabad. The minimalist decor really helps you focus on the flavors.",
    date: "2 days ago"
  },
  {
    id: 2,
    name: "Sarah Jones",
    rating: 4,
    comment: "Beautiful atmosphere. The Dim Sum was spectacular, though the wait time was a bit longer than expected during rush hour.",
    date: "1 week ago"
  },
  {
    id: 3,
    name: "Rohan Das",
    rating: 5,
    comment: "Perfect spot for remote work. The WiFi is fast and the coffee keeps coming. A true sanctuary.",
    date: "3 weeks ago"
  }
];

const ReviewSection: React.FC = () => {
  const [reviews, setReviews] = useState<Review[]>(initialReviews);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  const handleAddReview = (newReview: Omit<Review, 'id' | 'date'>) => {
    const review: Review = {
      ...newReview,
      id: Date.now(),
      date: "Just now"
    };
    setReviews([review, ...reviews]);
  };

  const loadMoreReviews = async () => {
    if (!process.env.API_KEY) {
      alert("AI Review Generation is disabled: API Key not found.");
      return;
    }

    setIsLoadingMore(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: "Generate 3 realistic customer reviews for Café Ikigai, a premium minimalist cafe in Kondapur, Hyderabad. Mention specific details like their Shroom Coffee (Lion's Mane, Cordyceps), Dim Sum, Sourdough, or the zen atmosphere. Keep the tone sophisticated and authentic.",
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                rating: { type: Type.NUMBER },
                comment: { type: Type.STRING },
              },
              required: ["name", "rating", "comment"],
            },
          },
        },
      });

      const text = response.text;
      if (text) {
        const newReviewsData = JSON.parse(text);
        const processedNewReviews: Review[] = newReviewsData.map((r: any, index: number) => ({
          id: Date.now() + index,
          name: r.name,
          rating: r.rating,
          comment: r.comment,
          date: `${Math.floor(Math.random() * 4) + 1} weeks ago`
        }));
        setReviews(prev => [...prev, ...processedNewReviews]);
      }
    } catch (error) {
      console.error("Error generating reviews:", error);
      alert("Failed to generate more reviews. Please try again later.");
    } finally {
      setIsLoadingMore(false);
    }
  };

  return (
    <section className="py-40 bg-charcoal border-t border-white/5" id="reviews">
      <div className="container mx-auto px-6 lg:px-20">
        <div className="flex flex-col md:flex-row justify-between items-end mb-24 gap-12">
          <div>
            <span className="text-primary uppercase tracking-[0.4em] text-[10px] font-black mb-4 block">The Community Voice</span>
            <h2 className="text-5xl md:text-7xl mb-4">Guest Experiences</h2>
          </div>
          <button 
            onClick={() => setIsReviewModalOpen(true)}
            className="group relative px-10 py-5 bg-transparent border border-white/20 text-white uppercase tracking-[0.2em] text-[10px] font-black overflow-hidden hover:border-primary transition-all"
          >
            <div className="absolute inset-0 bg-primary -translate-x-full group-hover:translate-x-0 transition-transform duration-500"></div>
            <span className="relative z-10">Share Your Story</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {reviews.map((review) => (
            <div 
              key={review.id} 
              className="tilt-card p-12 border border-white/5 bg-[#0f0f0f] flex flex-col h-full hover:border-primary/20 transition-all shadow-xl"
              style={{ perspective: '1000px' }}
            >
              <div className="flex text-primary mb-8 gap-1">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className={`material-symbols-outlined text-sm ${i < review.rating ? 'text-fill' : 'opacity-10'}`}>
                    star
                  </span>
                ))}
              </div>
              <p className="text-cream/70 italic font-light leading-relaxed mb-10 flex-grow text-lg">
                "{review.comment}"
              </p>
              <div className="mt-auto pt-8 border-t border-white/5 flex justify-between items-center">
                <div>
                  <span className="font-display text-brass block text-xl">{review.name}</span>
                  <span className="text-[10px] uppercase tracking-[0.2em] text-white/20 font-bold">Verified Guest</span>
                </div>
                <span className="text-[10px] uppercase tracking-widest text-white/20 font-black">{review.date}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-24 text-center">
          <button 
            onClick={loadMoreReviews}
            disabled={isLoadingMore}
            className="group inline-flex items-center gap-4 px-12 py-6 border border-white/5 hover:border-primary/40 transition-all backdrop-blur-sm"
          >
            {isLoadingMore ? (
              <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full"></div>
            ) : (
              <span className="material-symbols-outlined text-primary text-xl">refresh</span>
            )}
            <span className="uppercase tracking-[0.3em] text-[10px] font-black text-white">
              {isLoadingMore ? 'Consulting Archives...' : 'Load More Experiences'}
            </span>
          </button>
        </div>
      </div>

      <ReviewModal 
        isOpen={isReviewModalOpen} 
        onClose={() => setIsReviewModalOpen(false)} 
        onSubmit={handleAddReview} 
      />
    </section>
  );
};

export default ReviewSection;
