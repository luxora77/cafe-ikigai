
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Menu from './components/Menu';
import Ambience from './components/Ambience';
import ReviewSection from './components/ReviewSection';
import Testimonial from './components/Testimonial';
import VisitUs from './components/VisitUs';
import Footer from './components/Footer';
import ReservationModal from './components/ReservationModal';

const App: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px"
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    }, observerOptions);

    document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="relative min-h-screen bg-charcoal selection:bg-primary selection:text-white">
      {/* Texture Overlay for premium look */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] z-[100] bg-[url('https://www.transparenttextures.com/patterns/asfalt-dark.png')]"></div>
      
      <Header onReserve={openModal} />
      
      <main className="space-y-0">
        <Hero />
        
        <div className="reveal">
          <About />
        </div>

        <div className="reveal">
          <Menu />
        </div>

        <div className="reveal">
          <Ambience />
        </div>

        <div className="reveal">
          <ReviewSection />
        </div>

        <div className="reveal">
          <Testimonial />
        </div>

        <div className="reveal">
          <VisitUs />
        </div>
      </main>

      <Footer />

      {/* 3D Floating Action Button */}
      <div className="fixed bottom-10 right-10 z-40 hidden md:block" style={{ perspective: '500px' }}>
        <button 
          onClick={openModal}
          className="bg-primary text-white p-6 shadow-2xl hover:bg-accent transition-all duration-500 hover:-translate-y-2 hover:rotate-x-12 active:translate-y-0 group border border-white/10"
        >
          <div className="flex items-center gap-4">
            <span className="material-symbols-outlined">calendar_month</span>
            <span className="uppercase tracking-[0.2em] font-bold text-xs">Book Experience</span>
          </div>
        </button>
      </div>

      <div className="fixed bottom-6 right-6 md:hidden z-40">
        <button 
          onClick={openModal}
          className="bg-primary text-white p-5 rounded-full shadow-2xl active:scale-90 transition-transform border border-white/20"
        >
          <span className="material-symbols-outlined">restaurant</span>
        </button>
      </div>

      <ReservationModal isOpen={isModalOpen} onClose={closeModal} />
    </div>
  );
};

export default App;
