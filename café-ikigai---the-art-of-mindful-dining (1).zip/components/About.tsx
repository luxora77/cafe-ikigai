
import React from 'react';

const About: React.FC = () => {
  return (
    <section className="py-32 bg-chocolate text-[#fcfaf8]" id="about">
      <div className="container mx-auto px-6 lg:px-20">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="relative group">
            <div className="overflow-hidden">
              <img 
                alt="Ikigai Coffee" 
                className="w-full h-[600px] object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-105" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuD-vJgm2GQbIk9zkuPDSmxpCQ21OLqcZHJQLtcb8fFhdjSa21Hi8KEZd-u0TM1Vr9LtrYBj3bGr19g1Ad-Sn0y8mM7sZ19B2Bakv5bF8EpW6gzWW_jvPlzES6i9vvtVkaf9K-xOmD2rUfPffsGChHlS3z4JoHV5GIjsMYoqhRVe4xLwxalIiWsxg72PhcPrQ5QNVrVsX9UDxKoENOzypmeBFrdkRvoeBRB1YQ4KReS2EudhPY-7s0EIUGn_eSaaJ_utqAboCKynSE4"
              />
            </div>
            <div className="absolute -bottom-10 -right-10 bg-primary p-12 hidden md:block shadow-2xl">
              <span className="text-4xl font-display italic text-white">Since 2021</span>
            </div>
          </div>
          
          <div className="space-y-8">
            <h2 className="text-5xl md:text-6xl leading-tight">Beyond the Plate: The Spirit of Ikigai</h2>
            <p className="text-lg text-white/70 leading-relaxed font-light">
              Our name reflects the ancient Japanese wisdom of finding your "reason for being." At Café Ikigai, we believe food is the ultimate catalyst for connection. We've curated a space where every grain of coffee and every fold of dough is a meditation on quality.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6">
              <div className="p-6 border border-white/5 hover:border-primary/30 transition-colors">
                <h4 className="text-primary text-xl mb-3 italic">Zen Minimalism</h4>
                <p className="text-sm opacity-60">Architectural lines meet soft, natural textures to create a headspace of pure tranquility.</p>
              </div>
              <div className="p-6 border border-white/5 hover:border-primary/30 transition-colors">
                <h4 className="text-primary text-xl mb-3 italic">Curated Terroir</h4>
                <p className="text-sm opacity-60">We source single-origin beans and farm-fresh ingredients to bring you authentic, vibrant flavors.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
