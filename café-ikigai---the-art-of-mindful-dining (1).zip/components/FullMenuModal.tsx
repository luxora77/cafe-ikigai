
import React from 'react';

interface FullMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const FullMenuModal: React.FC<FullMenuModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const menuPages = [
    {
      title: "Shroom Coffee & Signatures",
      url: "https://images.unsplash.com/photo-1559496417-e7f25cb247f3?q=80&w=1200&auto=format&fit=crop"
    },
    {
      title: "Hot & Cold Brews",
      url: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=1200&auto=format&fit=crop"
    },
    {
      title: "Kitchen & All Day Breakfast",
      url: "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?q=80&w=1200&auto=format&fit=crop"
    }
  ];

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 md:p-10">
      <div 
        className="absolute inset-0 bg-charcoal/95 backdrop-blur-2xl"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-5xl h-full max-h-[90vh] flex flex-col animate-in fade-in zoom-in duration-500">
        <div className="flex justify-between items-center mb-6 px-4">
          <h2 className="text-3xl font-display italic text-cream">Digital Menu Catalogue</h2>
          <button 
            onClick={onClose}
            className="size-12 rounded-full border border-white/10 flex items-center justify-center text-white hover:bg-primary hover:border-primary transition-all group"
          >
            <span className="material-symbols-outlined group-hover:rotate-90 transition-transform">close</span>
          </button>
        </div>

        <div className="flex-grow overflow-y-auto space-y-10 px-4 pb-20 custom-scrollbar">
          {menuPages.map((page, index) => (
            <div key={index} className="space-y-4">
              <span className="text-[10px] uppercase tracking-[0.4em] text-primary font-black">Page 0{index + 1} — {page.title}</span>
              <div className="border border-white/5 shadow-2xl overflow-hidden bg-white/5 aspect-[3/4] md:aspect-auto">
                <img 
                  src={page.url} 
                  alt={page.title} 
                  className="w-full h-auto object-contain"
                  loading="lazy"
                />
              </div>
            </div>
          ))}
        </div>
        
        <div className="absolute bottom-0 left-0 w-full p-8 bg-gradient-to-t from-charcoal to-transparent pointer-events-none">
          <p className="text-center text-white/40 text-[10px] uppercase tracking-widest font-bold">
            Scroll to explore all pages
          </p>
        </div>
      </div>
    </div>
  );
};

export default FullMenuModal;
