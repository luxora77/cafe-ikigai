
import React, { useState } from 'react';
import FullMenuModal from './FullMenuModal';

const menuData = [
  {
    category: 'Shroom Coffee',
    items: [
      { name: "Lion's Mane Coffee", price: "129/-", desc: "Focus, Anti-Memory, Cognitive Health" },
      { name: "Cordyceps Coffee", price: "129/-", desc: "Acute Energy, Immune Support" },
      { name: "Reishi Shroom Coffee", price: "129/-", desc: "Calm the mind, Stress relief, Sleep quality" },
      { name: "Curcumin Latte", price: "129/-", desc: "Build Immunity, Fight Inflammation" },
    ]
  },
  {
    category: 'Hot Coffees',
    items: [
      { name: "Espresso (Single/Double)", price: "140/180/-", desc: "Pure caffeine kick" },
      { name: "Americano", price: "180/-", desc: "Espresso with hot water" },
      { name: "Cappuccino", price: "190/-", desc: "Balanced espresso, milk & foam" },
      { name: "Caffe Latte", price: "200/-", desc: "Silky milk over espresso" },
      { name: "Flat White", price: "210/-", desc: "Intense espresso with microfoam" },
      { name: "Mocha", price: "230/-", desc: "Chocolate infused latte" },
    ]
  },
  {
    category: 'Kitchen Specials',
    items: [
      { name: "Avocado Toast", price: "380/-", desc: "Hass avocado on fresh sourdough" },
      { name: "Wild Mushroom Sourdough", price: "340/-", desc: "Creamy mushrooms & herbs" },
      { name: "Crystal Veg Dim Sum", price: "340/-", desc: "Steamed garden parcels" },
      { name: "Truffle Fries", price: "280/-", desc: "With parmesan and parsley" },
    ]
  },
  {
    category: 'Teas & Infusions',
    items: [
      { name: "Assam Gold", price: "160/-", desc: "Classic black tea" },
      { name: "Hibiscus Rose", price: "180/-", desc: "Floral and tart infusion" },
      { name: "Matcha Latte", price: "240/-", desc: "Ceremonial grade green tea" },
      { name: "Chamomile Zen", price: "170/-", desc: "Calming herbal floral brew" },
    ]
  }
];

const Menu: React.FC = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [isFullMenuOpen, setIsFullMenuOpen] = useState(false);

  return (
    <section className="py-40 bg-charcoal relative" id="menu">
      <div className="container mx-auto px-6 lg:px-20">
        <div className="text-center mb-24">
          <span className="text-primary uppercase tracking-[0.4em] text-[10px] font-black mb-4 block">Crafted with Purpose</span>
          <h2 className="text-5xl md:text-7xl mb-4 font-display">The Ikigai Menu</h2>
          <div className="h-px w-32 bg-primary/30 mx-auto mb-8"></div>
        </div>
        
        <div className="bg-[#0f0f0f] border border-white/5 p-8 md:p-20 relative overflow-hidden shadow-inner">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2"></div>
          
          <div className="flex flex-wrap gap-10 justify-center mb-24 border-b border-white/5 pb-10">
            {menuData.map((cat, idx) => (
              <button 
                key={idx}
                onClick={() => setActiveTab(idx)}
                className={`uppercase tracking-[0.3em] text-[10px] font-black transition-all relative px-4 ${
                  activeTab === idx ? 'text-primary scale-110' : 'text-white/20 hover:text-white/60'
                }`}
              >
                {cat.category}
                {activeTab === idx && (
                  <div className="absolute -bottom-[41px] left-0 w-full h-0.5 bg-primary shadow-[0_0_10px_rgba(217,119,6,0.5)]"></div>
                )}
              </button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-x-32 gap-y-16 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {menuData[activeTab].items.map((item, idx) => (
              <div key={idx} className="group border-b border-white/5 pb-8 hover:border-primary/20 transition-all">
                <div className="flex justify-between items-baseline mb-3">
                  <h4 className="text-2xl font-display text-cream group-hover:translate-x-3 transition-transform duration-500">
                    {item.name}
                  </h4>
                  <div className="flex-grow mx-4 border-b border-white/5 border-dotted h-0.5"></div>
                  <span className="text-primary font-mono font-bold">{item.price}</span>
                </div>
                <p className="text-white/20 text-xs font-light italic uppercase tracking-widest leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-24 text-center">
           <p className="text-white/20 text-xs uppercase tracking-[0.4em] mb-12">All prices are inclusive of local taxes</p>
           <button 
             onClick={() => setIsFullMenuOpen(true)}
             className="px-16 py-6 border border-white/10 hover:border-primary/50 text-white uppercase tracking-[0.3em] text-[10px] font-black transition-all hover:bg-white/5 group shadow-2xl"
           >
             View Full Digital Menu <span className="material-symbols-outlined align-middle ml-4 text-primary group-hover:translate-x-2 transition-transform">auto_stories</span>
           </button>
        </div>
      </div>

      <FullMenuModal isOpen={isFullMenuOpen} onClose={() => setIsFullMenuOpen(false)} />
    </section>
  );
};

export default Menu;
