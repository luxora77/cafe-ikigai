
import React from 'react';

const Ambience: React.FC = () => {
  return (
    <section className="py-32 bg-chocolate" id="ambience">
      <div className="container mx-auto px-6 lg:px-20">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <div className="lg:w-1/3">
            <h2 className="text-5xl md:text-6xl mb-8">The Social Atmosphere</h2>
            <p className="text-white/60 text-lg mb-8 leading-relaxed font-light">
              From quiet nooks for deep focus to communal tables that spark conversation, our space evolves throughout the day.
            </p>
            <ul className="space-y-6">
              <li className="flex items-center gap-4 text-brass group cursor-default">
                <span className="material-symbols-outlined transition-transform group-hover:scale-125">menu_book</span>
                <span className="uppercase tracking-widest text-xs font-bold">Curated Library</span>
              </li>
              <li className="flex items-center gap-4 text-brass group cursor-default">
                <span className="material-symbols-outlined transition-transform group-hover:scale-125">wifi</span>
                <span className="uppercase tracking-widest text-xs font-bold">Hyper-speed Connectivity</span>
              </li>
              <li className="flex items-center gap-4 text-brass group cursor-default">
                <span className="material-symbols-outlined transition-transform group-hover:scale-125">deck</span>
                <span className="uppercase tracking-widest text-xs font-bold">Al Fresco Terrace</span>
              </li>
            </ul>
          </div>
          
          <div className="lg:w-2/3 grid grid-cols-2 gap-4">
            <div className="overflow-hidden">
              <img 
                alt="Vibe 1" 
                className="w-full h-[400px] object-cover hover:scale-110 transition-transform duration-1000" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAKkN-zDPfc6RCDKas_i6FTjvvp3RNnGe6f5vy2z9HFg2hhMY7ZA0yfCo9bUG2yTwlDEmq5v04YwnHLiRqr5LyFcaWuwse1rse9DHdab2hFgnUE7_B7hYhvwsI1gZDwgE0Wz1RKMTPxyEE6IAocMo11O9nVWSIpkv0WPVS0hrONqPkGRMB-115XqMIQi7grA0qfL3Zj8g8BTxhfB8LJBodsRNlyHjVqR-Ud8hbDVOwWfIvd_11UffX5T8zSEifUa978TYSajr-3mzc"
              />
            </div>
            <div className="grid gap-4">
              <div className="overflow-hidden">
                <img 
                  alt="Vibe 2" 
                  className="w-full h-[190px] object-cover hover:scale-110 transition-transform duration-1000" 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuBXmDvl7HvNVcOE4EBH-91q8G4L5CXIBvrIH95KB2w1ZLBTNu-Oeae6f7D5HhyjpUSm9h8Kg4TZFA8lZ_8lSyzGqetbg7fxywhmuPKJl4TjjbFxx3IjDK92lz3odq81-TOBr7vu6QqLTAhJKuc89noBKPOjERdTStL2qkJ9S0tRCCfQe2pmFlJUYY9SfX8GMRuNa7gviZN3Dl1dvC1uymHiRcchvc-vh2l8u3ztWJXNKkMSHHiuyWYEwUaOZYNLrOLBUmsV2XaBHOc"
                />
              </div>
              <div className="overflow-hidden">
                <img 
                  alt="Vibe 3" 
                  className="w-full h-[190px] object-cover hover:scale-110 transition-transform duration-1000" 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDoTUwv0TVU5grICGh9h5A59-nMIfeQ5LsfqN4r2esR1k9MC3igDsNTsFMoCZoJDetbCsgzoO6tuKzoiqXvnyXNxZJuEhQ7SMEerrYY_veK0d9ZCxPG8bZZ554noXB0VrcTtqx_S_4twss6U5Xlz4PFC2az1vpTMhV5JjU_fCVSAYTBOhvnzeKH5l29fR6YTTdBnREibjDCUNoCKcqlaJyYh2b2JXWEsGUsY2DewijVmncC8hiXoLcSDCm0rLRtMO95T-ekME9aLzY"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Ambience;
