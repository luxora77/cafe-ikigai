
import React, { useEffect, useState } from 'react';

const Hero: React.FC = () => {
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    const handleScroll = () => setOffset(window.pageYOffset);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToId = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 100;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="relative h-[110vh] flex items-center overflow-hidden">
      <div 
        className="absolute inset-0 z-0 scale-110"
        style={{ transform: `translateY(${offset * 0.4}px)` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal/20 via-charcoal/80 to-charcoal z-10"></div>
        <img 
          alt="Cafe Interior" 
          className="w-full h-full object-cover" 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuDMcJLUszWYcr_vAHCr5JtQcjys3Q6kL8rmCiZujO4uS35-9LBzk9UBxpjFLjlcq-ZCJbYzkxiB49mmlLsnhOa2_05wMT-g7RsVG4tYe4cX_yfwROZQfUazRXLuhLTWP8DItsqbsdF_gmYB6mrNV505sh3MOM1-501KfWt40Zi_DoUsGDFafSrjGmZpQwJSHcR69QOi6Gv6nj8e52FvDGT28gKOQOoHCQMnyMR0e0c3-ZtifIbtHAdZd0sZ_aBSPRcTIKPeUYUvy_8"
        />
      </div>
      
      <div 
        className="relative z-20 container mx-auto px-6 lg:px-20 transition-transform duration-300"
        style={{ transform: `translateY(${-offset * 0.15}px)` }}
      >
        <div className="max-w-4xl">
          <div className="overflow-hidden mb-6">
            <span className="inline-block text-primary uppercase tracking-[0.5em] font-bold text-xs animate-in slide-in-from-bottom duration-1000">
              A Hyderabad Original
            </span>
          </div>
          <h1 className="text-6xl md:text-9xl leading-tight mb-8 text-gradient drop-shadow-2xl font-display">
            Mindful <br /> Dining.
          </h1>
          <p className="text-xl md:text-2xl text-white/60 font-light leading-relaxed mb-12 max-w-xl border-l-2 border-primary/30 pl-8">
            Where Japanese precision meets the soulful warmth of Indian hospitality. A sanctuary for the culinary curious.
          </p>
          <div className="flex flex-col sm:flex-row gap-6">
            <button 
              onClick={() => scrollToId('menu')} 
              className="group relative px-12 py-6 bg-white text-charcoal font-bold uppercase text-xs tracking-[0.2em] overflow-hidden transition-all hover:text-white"
            >
              <div className="absolute inset-0 bg-primary translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              <span className="relative z-10">Explore the Menu</span>
            </button>
            <button 
              onClick={() => scrollToId('contact')} 
              className="px-12 py-6 border border-white/10 hover:border-white/40 backdrop-blur-sm transition-all uppercase text-xs tracking-[0.2em] flex items-center gap-4 group"
            >
              Find Us <span className="material-symbols-outlined text-primary group-hover:translate-x-2 transition-transform">arrow_forward</span>
            </button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 animate-bounce opacity-40">
        <span className="material-symbols-outlined text-4xl">expand_more</span>
      </div>
    </section>
  );
};

export default Hero;
