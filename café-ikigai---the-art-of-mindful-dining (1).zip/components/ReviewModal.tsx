
import React, { useState } from 'react';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (review: { name: string; rating: number; comment: string }) => void;
}

const ReviewModal: React.FC<ReviewModalProps> = ({ isOpen, onClose, onSubmit }) => {
  const [name, setName] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ name, rating, comment });
    setName('');
    setRating(5);
    setComment('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-charcoal/90 backdrop-blur-sm"
        onClick={onClose}
      />
      
      <div className="relative bg-[#1a1a1a] border border-white/10 w-full max-w-lg p-10 shadow-2xl animate-in fade-in zoom-in duration-300">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-white/50 hover:text-white"
        >
          <span className="material-symbols-outlined">close</span>
        </button>
        
        <h2 className="text-3xl font-display mb-2 text-cream">Write a Review</h2>
        <p className="text-white/40 text-xs uppercase tracking-widest mb-8">Tell us about your time at Ikigai</p>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] uppercase tracking-[0.2em] text-brass font-bold">Your Name</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Rahul Sharma" 
              required
              className="w-full bg-white/5 border border-white/10 p-4 focus:outline-none focus:border-primary transition-colors text-sm text-white"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] uppercase tracking-[0.2em] text-brass font-bold">Rating</label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className={`material-symbols-outlined text-2xl transition-all ${star <= rating ? 'text-primary' : 'text-white/10'}`}
                >
                  star
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] uppercase tracking-[0.2em] text-brass font-bold">Your Comment</label>
            <textarea 
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Describe your experience..." 
              required
              rows={4}
              className="w-full bg-white/5 border border-white/10 p-4 focus:outline-none focus:border-primary transition-colors text-sm text-white resize-none"
            />
          </div>
          
          <button 
            type="submit"
            className="w-full bg-primary hover:bg-accent py-5 uppercase tracking-widest font-bold text-xs transition-all shadow-xl text-white"
          >
            Post Review
          </button>
        </form>
      </div>
    </div>
  );
};

export default ReviewModal;
