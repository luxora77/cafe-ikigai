
import React from 'react';

const Testimonial: React.FC = () => {
  return (
    <section className="py-32 bg-charcoal border-y border-white/5">
      <div className="container mx-auto px-6 lg:px-20">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center gap-1 text-primary mb-8">
            <span className="material-symbols-outlined text-fill">star</span>
            <span className="material-symbols-outlined text-fill">star</span>
            <span className="material-symbols-outlined text-fill">star</span>
            <span className="material-symbols-outlined text-fill">star</span>
            <span className="material-symbols-outlined text-fill">star</span>
          </div>
          <blockquote className="text-3xl md:text-5xl font-display italic leading-snug mb-12 text-cream">
            "An oasis of calm in the city. The attention to culinary detail is unmatched in Hyderabad. Every visit feels like a ritual."
          </blockquote>
          <div className="h-px w-20 bg-primary mx-auto mb-6"></div>
          <p className="text-sm uppercase tracking-[0.3em] font-bold text-white/80">Ananya R. — Culinary Critic</p>
        </div>
      </div>
    </section>
  );
};

export default Testimonial;
